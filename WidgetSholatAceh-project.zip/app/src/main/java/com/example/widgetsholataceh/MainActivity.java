package com.example.widgetsholataceh;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(28, 28, 28, 28);
        page.setBackgroundColor(Color.rgb(8, 27, 37));

        TextView title = new TextView(this);
        title.setText("🕌 Widget Sholat Aceh");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);

        TextView help = new TextView(this);
        help.setText("Widget jadwal sholat Aceh Tamiang.\n\nUntuk memasang: kembali ke layar utama, tekan dan tahan area kosong, pilih Widget, lalu cari Widget Sholat Aceh.\n\nPastikan internet aktif agar jadwal dapat diperbarui.");
        help.setTextColor(Color.WHITE);
        help.setTextSize(16);
        help.setGravity(Gravity.CENTER);
        help.setPadding(8, 24, 8, 8);

        page.addView(title);
        page.addView(help);
        setContentView(page);
    }
}
