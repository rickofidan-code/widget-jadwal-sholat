package com.example.widgetsholataceh;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PrayerWidgetProvider extends AppWidgetProvider {
    private static final String ACTION_TICK = "com.example.widgetsholataceh.UPDATE_WIDGET";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        scheduleRefresh(context);
        refreshAll(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_TICK.equals(intent.getAction())) refreshAll(context);
    }

    @Override
    public void onEnabled(Context context) {
        scheduleRefresh(context);
    }

    private static void scheduleRefresh(Context context) {
        Intent intent = new Intent(context, PrayerWidgetProvider.class);
        intent.setAction(ACTION_TICK);
        PendingIntent pending = PendingIntent.getBroadcast(context, 1001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms != null) {
            // Android dapat menunda alarm inexact demi penghematan baterai.
            alarms.setInexactRepeating(AlarmManager.RTC,
                    System.currentTimeMillis() + 15 * 60 * 1000L,
                    15 * 60 * 1000L, pending);
        }
    }

    private static void refreshAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(
                new ComponentName(context, PrayerWidgetProvider.class));
        if (ids.length == 0) return;

        for (int id : ids) {
            RemoteViews loading = new RemoteViews(context.getPackageName(), R.layout.widget_prayer);
            loading.setTextViewText(R.id.widget_clock,
                    new SimpleDateFormat("HH:mm", new Locale("id", "ID")).format(new Date()));
            loading.setTextViewText(R.id.widget_status, "Memuat jadwal sholat…");
            manager.updateAppWidget(id, loading);
        }

        EXECUTOR.execute(() -> {
            try {
                String endpoint = "https://api.aladhan.com/v1/timingsByCity?city=Kuala%20Simpang&country=Indonesia&method=20";
                HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(connection.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line);
                } finally {
                    connection.disconnect();
                }

                JSONObject timings = new JSONObject(body.toString())
                        .getJSONObject("data").getJSONObject("timings");
                String[] names = {"Subuh", "Zuhur", "Asar", "Magrib", "Isya"};
                String[] keys = {"Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"};
                String[] values = new String[5];
                StringBuilder rows = new StringBuilder();
                for (int i = 0; i < keys.length; i++) {
                    values[i] = clean(timings.getString(keys[i]));
                    rows.append(String.format(Locale.getDefault(), "%-9s %s", names[i], values[i]));
                    if (i < keys.length - 1) rows.append("\n");
                }

                long now = System.currentTimeMillis();
                long best = Long.MAX_VALUE;
                String nextName = "Subuh";
                String nextTime = values[0];
                SimpleDateFormat parser = new SimpleDateFormat("HH:mm", Locale.US);
                for (int i = 0; i < values.length; i++) {
                    Date parsed = parser.parse(values[i]);
                    if (parsed == null) continue;
                    Calendar candidate = Calendar.getInstance();
                    Calendar parsedCal = Calendar.getInstance();
                    parsedCal.setTime(parsed);
                    candidate.set(Calendar.HOUR_OF_DAY, parsedCal.get(Calendar.HOUR_OF_DAY));
                    candidate.set(Calendar.MINUTE, parsedCal.get(Calendar.MINUTE));
                    candidate.set(Calendar.SECOND, 0);
                    candidate.set(Calendar.MILLISECOND, 0);
                    if (candidate.getTimeInMillis() <= now)
                        candidate.add(Calendar.DAY_OF_YEAR, 1);
                    long diff = candidate.getTimeInMillis() - now;
                    if (diff < best) {
                        best = diff;
                        nextName = names[i];
                        nextTime = values[i];
                    }
                }

                long seconds = Math.max(0, best / 1000);
                String countdown = String.format(Locale.getDefault(),
                        "Menuju %s %s · %02dj %02dm",
                        nextName, nextTime, seconds / 3600, (seconds % 3600) / 60);

                for (int id : ids) {
                    RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_prayer);
                    views.setTextViewText(R.id.widget_clock,
                            new SimpleDateFormat("HH:mm", new Locale("id", "ID")).format(new Date()));
                    views.setTextViewText(R.id.widget_rows, rows.toString());
                    views.setTextViewText(R.id.widget_status, countdown);
                    manager.updateAppWidget(id, views);
                }
            } catch (Exception error) {
                for (int id : ids) {
                    RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_prayer);
                    views.setTextViewText(R.id.widget_status,
                            "Jadwal belum termuat. Periksa internet.");
                    manager.updateAppWidget(id, views);
                }
            }
        });
    }

    private static String clean(String value) {
        return value == null ? "--:--" : value.split(" ")[0];
    }
}
